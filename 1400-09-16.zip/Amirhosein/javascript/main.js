let d = new Date();
let rooz = "";
let payam = "";
switch (d.getDay()) {
    case 0:
        rooz = "یکشنبه"
        payam = "دلبرا خورشید تابان ذره‌ ایی از روی تست"
        break;
    case 1:
        rooz = "دوشنبه"
        payam = "در هوایت بی قرارم روز و شب سر ز پایت بر ندارم روز و شب"
        break;
    case 2:
        rooz = "سه شنبه"
        payam = "هر چه گویی آخری دارد به غیر از حرف عشق کاین همه گفتند و آخر نیست این افسانه را"
        break;
    case 3:
        rooz = "چهارشنبه"
        payam = "تو همانی که دلم لک زده لبخندش را او که هرگز نتوان یافت همانندش را …"
        break;
    case 4:
        rooz = "پنجشنبه"
        payam = "در نومیدی بسی امید است پایان شب سیه سپید است"
        break;
    case 5:
        rooz = "جمعه"
        payam = "ز یاران کینه هرگز در دل یاران نمی ماند به روی آب جای قطره ی باران نمی ماند"
        break;
    case 6:
        rooz = "شنبه"
        payam = "برگ درختان سبز در نظر هوشیار هر ورقش دفتری ست معرفت کردگار"
        break;
    default:
        txt = "روز مورد نظر پیدا نشد";
}
function showday() {
    document.getElementById('rooz').innerHTML = rooz;
    document.getElementById('payam').innerHTML = payam;
}