function theme(){
    var dtheme = document.getElementById('bck')
    dtheme.style.backgroundColor = "black"
}
function chname(){
    var namech = document.getElementById('chname')
    namech.innerHTML = " >> نام تغییر کرد <<"
}
function hidepic(){
    var mypic = document.getElementById('pic')
    mypic.style.visibility = "hidden"
}
function changepic(){
    var chpic = document.getElementById('pic')
    chpic.src = "images/pic2.jpg"
}